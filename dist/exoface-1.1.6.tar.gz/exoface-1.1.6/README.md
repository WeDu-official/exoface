<img src="https://github.com/user-attachments/assets/a1b834d0-44dd-405d-8db5-2855a35d7232" alt="exofacelogo-removebg-preview" width="500">

**exoface** a library for facial recognition(everything from training to recognizing)

**NOTE: THE exoface ONLY work in almost any operating system(\*1) which can support python 3.10 and above**

**\*1: THE exoface wasn't tested on any operating system expect window
and the 32-bit version of it wasn't tested, only window 64-bit operating system was tested**

**exoface** is a very powerful way to make facial recognition possible in your application, and it has been made
to help developers esp. **single developers** to implement facial recognition easily into their applications
,and it features (multiple users,training,storing and recognizing faces).

## Install

to install use the following command

<code>pip install exoface</code>

## Contribute

if you have discovered a bug, or you want to change something just open a new issue
at [Issues](https://github.com/WeDu-official/exoface/issues)

## Contact

you can contact us using this [email](mailto:fplu.the.founder@gmail.com)
,and you can be a part of our community by joining [our discord server](https://discord.gg/mnduzx6yUg)
